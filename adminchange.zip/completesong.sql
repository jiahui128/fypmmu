INSERT INTO recordedsong (rsong_id, rsong_no, rsong_name, rsong_album, rsong_artist, rsong_files) VALUES
			('101', '1', 'Kimi Ni Todoke', 'Kimi Ni Todoke', 'Tanizawa Tomofumi', 'Kimi_Ni_Todoke.mp3'),
			('102', '2', 'Where You Are', 'Moana', 'Disney Music Vevo', 'whereyouare.mp3'),
			('103', '3', 'Everything is Alright', 'To the Moon', 'Laura Shigihara', 'every.mp3'),
			('104', '4', 'Something There', 'Beauty and the Beast', 'Disney Music Vevo', 'something.mp3'),
			('105', '5', 'Negaraku', 'Malaysia Records', 'Pierre-Jean de Beranger', 'Negaraku.mp3'),
			('106', '6', 'One Thousand Years Later', 'Code 89757', 'Wayne Lin Jun Jie', 'onethousandyears.mp3'),
			('107', '7', 'As a Light Smoke', 'Unknown', 'IRiS (Tomo)', 'onmyoji.mp3'),
			('108', '8', 'Amazing Grace', 'On a Blue Ridge Sunday', 'John Newton', 'amazinggrace.mp3');