<?php
session_start();

$connection = mysqli_connect("localhost","root","","adminpanel");

if(isset($_POST['loginbtn'])) {
    $result=mysqli_query($connection, "SELECT * FROM register
    WHERE admin_email= '{$_POST['email']}'");
    $pass=mysqli_fetch_array($result);
    if($pass["admin_password"] === $_POST['password']) {
        session_start();
        $_SESSION['loggedin']=true;
        header("Location: index.php");
        exit;
    }
    else {
        echo '<script>';
		echo 'alert("Login unsuccessfully! Please try again");';
		echo 'location.href="login.php"';
		echo '</script>';
    }
}


?>