<?php 
include('includes/header.php'); 
?>   

<body style="background: lightgray;">

<div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-6 col-lg-6 col-md-6">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="p-5">

                                    <div class="text-center">
									
                                        <a href="http://localhost/FYP/newhome.php"><img src="SoFo.png" alt="SoFo Logo" style="width: 250px; height: 80px; float: center;" title="This is SoFo Logo" /></a>
                                    
										<br><br>
										
										<h1 class="h4 text-gray-900 mb-4" style="font-weight: bold;">Admin Login</h1>
										
										<p style="color: black;">Enter your email address and password below to continue</p>
									
										<br>
									
									</div>
									
									<div>
									<?php
									if(isset($_SESSION['success']) && $_SESSION['success'] !='')
									{
										echo '<h2 class="bg-primary text-white"> '.$_SESSION['success'].'</h2>';
										unset($_SESSION['success']);
									}

									if(isset($_SESSION['status']) && $_SESSION['status'] !='')
									{
										echo '<h2 class="bg-danger text-white"> '.$_SESSION['status'].'</h2>';
										unset($_SESSION['status']);
									}
									?>
									</div>
									
                                    <form class="user" action="logincode.php" method="POST">

                                        <div class="form-group">
                                            <input type="email" name="email" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                        </div>
                                        
										<div class="form-group">
                                            <input type="password" name="password" class="form-control form-control-user"id="exampleInputPassword" placeholder="Enter Password...">
                                        </div>
										
										<div style="text-align: left; text-decoration: none;">
										
										<a href="http://localhost/FYP/newhome.php">Forgot Password?</a>
										
										</div>
										
										<br>
                                        
										<button type="submit" name="loginbtn" class="btn btn-primary btn-user btn-block" style="font-weight: bold; color: white; font-size: 15px;">Login Account</button>
								
									</form>
									
										<br>
										
										<div class="text-center" style="text-decoration: underline;">
										
										<a href="http://localhost/FYP/newhome.php">Back to Home Page</a>
										
										</div>
										
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
	
</div>

<!-- End of Main Content -->
<?php 
include('includes/footer.php'); 
?>   
       
<?php
include('includes/scripts.php');
?>

</body>  