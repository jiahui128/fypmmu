<?php 
	$con = mysqli_connect('localhost', 'root', '');
	
	if($con)
		{
			echo "";
			
			mysqli_query($con, "CREATE DATABASE SONGFORM");
			mysqli_select_db($con, "SONGFORM");
								
			mysqli_query($con, "CREATE TABLE recordedsong (rsong_id int auto_increment primary key,
								rsong_no int,
								rsong_name varchar(300),
								rsong_album varchar(300),
								rsong_artist varchar(300),
								rsong_files varchar(50000),
								created_at DATETIME DEFAULT CURRENT_TIMESTAMP);");
		
		}
 
?>