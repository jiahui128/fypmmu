<?php
session_start();


$connection = mysqli_connect("localhost","root","","songform");

if(isset($_POST['registerbtn']))
{ 
    $id = $_POST['id'];
	$no = $_POST['no'];
    $name = $_POST['name'];
    $status = $_POST['status'];
  
    $query = "INSERT INTO lyricstable (lyrics_no, lyrics_song, lyrics_status) VALUES ('$no', '$name','$status')";
    $query_run = mysqli_query($connection, $query);
            
        if($query_run)
        {
            // echo "Saved";
            $_SESSION['status'] = "New Lyrics Info Added";
            header('Location: lyricstable.php');
        }
        else 
        {
            $_SESSION['status'] = "New Lyrics Info Not Added";
            header('Location: lyricstable.php');  
        }
}

if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $no = $_POST['edit_no'];
    $name = $_POST['edit_name'];
    $status = $_POST['edit_status'];

    $query = "UPDATE lyricstable SET lyrics_no = '$no', lyrics_song='$name', lyrics_status='$status' WHERE lyrics_id='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Updated";
        header('Location: lyricstable.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        header('Location: lyricstable.php');
    }
}

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM lyricstable WHERE lyrics_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is DELETED";
        header('Location: lyricstable.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";
        header('Location: lyricstable.php');
    }
}

?>