            <!-- Footer -->
			
			<body style="color: grey;"
			
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto" style="color: black;">
                        
						<p>Posted By : SoFo Team</p>
						
						<p>Contact Us : <a href="mailto:1181202878@student.mmu.edu.my">Email(Vivian Quek)</a>
						/ <a href="mailto:1181203410@student.mmu.edu.my">Email(Ng Jia Hui)</a> / <a href="mailto:1191200801@student.mmu.edu.my">Email(Tan Wei Chin)</a></p>
		
						<small style="font-size: 14px; font: 14px sans-serif;">&copy; Copyright 2020, SoFo Team. All Rights Reserved.</small>
	
                    </div>
                </div>
				
            </footer>
			
			</body>
			
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

</body>

</html>