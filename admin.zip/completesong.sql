INSERT INTO recordedsong (rsong_name, rsong_album, rsong_artist) VALUES
			('Kimi Ni Todoke', 'Kimi Ni Todoke', 'Tanizawa Tomofumi'),
			('Where You Are', 'Moana', 'Disney Music Vevo'),
			('Everything is Alright', 'To the Moon', 'Laura Shigihara'),
			('Something There', 'Beauty and the Beast', 'Disney Music Vevo'),
			('Negaraku', 'Malaysia Records', 'Pierre-Jean de Beranger'),
			('One Thousand Years Later', 'Code 89757', 'Wayne Lin Jun Jie'),
			('As a Light Smoke', 'Unknown', 'IRiS (Tomo)'),
			('Amazing Grace', 'On a Blue Ridge Sunday', 'John Newton');