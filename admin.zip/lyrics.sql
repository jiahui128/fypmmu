INSERT INTO lyricstable (lyrics_id, lyrics_no, lyrics_song, lyrics_status) VALUES
			('101', '1', 'Kimi Ni Todoke', 'Completed'),
			('102', '2', 'Where You Are', 'Completed'),
			('103', '3', 'Everything is Alright', 'Completed'),
			('104', '4', 'Something There', 'Completed'),
			('105', '5', 'Negaraku', 'Completed'),
			('106', '6', 'One Thousand Years Later', 'Completed'),
			('107', '7', 'As a Light Smoke', 'Completed'),
			('108', '8', 'Amazing Grace', 'Completed');