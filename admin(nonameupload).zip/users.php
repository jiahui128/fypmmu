<?php
session_start();


$connection = mysqli_connect("localhost","root","","userform");

if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
    $name = $_POST['edit_name'];
    $email = $_POST['edit_email'];
	$gender = $_POST['edit_gender'];
	$age = $_POST['edit_age'];

    $query = "UPDATE usertable SET name='$name', email='$email', gender='$gender', age = '$age' WHERE id='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Updated";
        header('Location: userdata.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        header('Location: userdata.php');
    }
}
// Remove users
if(isset($_POST['remove_btn']))
{
    $id = $_POST['remove_id'];
	$user_situation = 1;
	$query = "UPDATE usertable SET situation='$user_situation' WHERE id='$id'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Remove";
        header('Location: userdata.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Remove";
        header('Location: userdata.php');
    }
}

//Delete users
if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];


    $query = "DELETE FROM usertable WHERE id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is DELETED";
        header('Location: removed_user.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";
        header('Location: removed_user.php');
    }
}

//Restore users
if(isset($_POST['restore_btn']))
{
    $id = $_POST['restore_id'];
	$user_situation = 0;
	$query = "UPDATE usertable SET situation='$user_situation' WHERE id='$id'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Restore";
        header('Location: removed_user.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Restore";
        header('Location: removed_user.php');
    }
}

?>