INSERT INTO lyricstable (lyrics_id, lyrics_no, lyrics_song, lyrics_status, lyrics_files) VALUES
			('101', '1', 'Kimi Ni Todoke', 'Completed', 'songlyrics1.pdf'),
			('102', '2', 'Where You Are', 'Completed', 'songlyrics2.pdf'),
			('103', '3', 'Everything is Alright', 'Completed', 'songlyrics3.pdf'),
			('104', '4', 'Something There', 'Completed', 'songlyrics4.pdf'),
			('105', '5', 'Negaraku', 'Completed', 'songlyrics5.pdf'),
			('106', '6', 'One Thousand Years Later', 'Completed', 'songlyrics6.pdf'),
			('107', '7', 'As a Light Smoke', 'Completed', 'songlyrics7.pdf'),
			('108', '8', 'Amazing Grace', 'Completed', 'songlyrics8.pdf');