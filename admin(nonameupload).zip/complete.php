<?php
session_start();


$connection = mysqli_connect("localhost","root","","songform");

if(isset($_POST['registerbtn']))
{ 
    $id = $_POST['id'];
    $name = $_POST['name'];
    $album = $_POST['album'];
    $artist = $_POST['artist'];
	$file = $_POST['file'];
	
	$q = "SELECT rsong_no FROM recordedsong ORDER BY rsong_no";
    $q_run = mysqli_query($connection, $q);

    $row = mysqli_num_rows($q_run);
	
	$no = $row+1;
  
    $query = "INSERT INTO recordedsong (rsong_name,rsong_no,rsong_album,rsong_artist, rsong_files) VALUES ('$name','$no','$album','$artist', '$file')";
    $query_run = mysqli_query($connection, $query);
            
        if($query_run)
        {
            // echo "Saved";
            $_SESSION['status'] = "Completed Song Added";
            header('Location: completesong.php');
        }
        else 
        {
            $_SESSION['status'] = "Completed Song Not Added";
            header('Location: completesong.php');  
        }
}

if(isset($_POST['addbtn']))
{ 
    $name = $_POST['name'];
    $album = $_POST['album'];
    $artist = $_POST['artist'];
	$file = $_POST['file'];
	
    $q = "SELECT rsong_no FROM recordedsong ORDER BY rsong_no";
    $q_run = mysqli_query($connection, $q);

    $row = mysqli_num_rows($q_run);
	
	$no = $row+1;
  
    $query = "INSERT INTO recordedsong (rsong_no, rsong_name,rsong_album,rsong_artist, rsong_files) VALUES ('$no', '$name','$album','$artist', '$file')";
    $query_run = mysqli_query($connection, $query);
            
        if($query_run)
        {
            // echo "Saved";
            $_SESSION['status'] = "Completed Song and Lyrics Data Updated";
            header('Location: completesong.php');
        }
        else 
        {
            $_SESSION['status'] = "Completed Song and Lyrics Data Not Updated";
            header('Location: completesong.php');  
        }
}

if(isset($_POST['updatebtn']))
{
    $id = $_POST['edit_id'];
	$no = $_POST['edit_no'];
    $name = $_POST['edit_name'];
    $album = $_POST['edit_album'];
    $artist = $_POST['edit_artist'];
	$file = $_POST['edit_file'];

    $query = "UPDATE recordedsong SET rsong_name='$name', rsong_no = '$no', rsong_album='$album', rsong_artist='$artist', rsong_files='$file' WHERE rsong_id='$id' ";
    $query_run = mysqli_query($connection,$query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Updated";
        header('Location: completesong.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Updated";
        header('Location: completesong.php');
    }
}

//Remove Lyrics
if(isset($_POST['remove_btn']))
{
    $id = $_POST['remove_id'];
	$situation = 1;
	$query = "UPDATE recordedsong SET status='$situation' WHERE rsong_id='$id'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Removed";
        header('Location: removed_song.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Removed";
        header('Location: removed_song.php');
    }
}

//Restore
//Remove Lyrics
if(isset($_POST['restore_btn']))
{
    $id = $_POST['restore_id'];
	$situation = 0;
	$query = "UPDATE recordedsong SET status='$situation' WHERE rsong_id='$id'";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is Removed";
        header('Location: completesong.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT Removed";
        header('Location: completesong.php');
    }
}

if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];

    $query = "DELETE FROM recordedsong WHERE rsong_id='$id' ";
    $query_run = mysqli_query($connection, $query);

    if($query_run)
    {
        $_SESSION['success'] = "Your Data is DELETED";
        header('Location: completesong.php');
    }
    else
    {
        $_SESSION['status'] = "Your Data is NOT DELETED";
        header('Location: completesong.php');
    }
}

?>