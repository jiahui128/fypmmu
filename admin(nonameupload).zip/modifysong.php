<?php
  include('complete.php');
  include('lyrics.php');
?>